
import os
import threading
import ipaddress
from time import sleep

devices = {}
progress = 0

def check(ip):
    global devices, progress
    response = os.system(f"ping -c 1 -W 1 {ip} > /dev/null 2>&1")
    if response == 0:
        # Now check if it's in the ARP table
        neigh_output = os.popen("ip neigh").read()
        for line in neigh_output.splitlines():
            if ip in line and "lladdr" in line:
                mac = line.split("lladdr")[1].split()[0]
                devices[ip] = mac
                break
    progress += 1

def netenum(network_cidr):
    global devices, progress
    devices = {}
    progress = 0

    try:
        net = ipaddress.ip_network(network_cidr, strict=False)
        threads = []
        for ip in net.hosts():
            thread = threading.Thread(target=check, args=(str(ip),))
            threads.append(thread)
            thread.start()
            sleep(0.01)

        for thread in threads:
            thread.join()
    except Exception as e:
        print(f"Error: {e}")
    return devices
